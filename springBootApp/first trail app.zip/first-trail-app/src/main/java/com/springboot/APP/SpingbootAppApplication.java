package com.springboot.APP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingbootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpingbootAppApplication.class, args);
	}

}
